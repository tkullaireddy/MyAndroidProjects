# Kotlin - ROOM Database

An Android app created with Kotlin and Room library.

<br />

## Demo

<img src="https://s3.gifyu.com/images/kotlin-room.gif" height="500px" />

<br />

## Reference

- [ROOM Database - Kotlin by Stevdza-San](https://www.youtube.com/playlist?list=PLSrm9z4zp4mEPOfZNV9O-crOhoMa0G2-o)

<br />

![Hello !](https://api.visitorbadge.io/api/VisitorHit?user=kevinadhiguna&repo=kotlin-room-database&label=thanks%20for%20dropping%20in%20!&labelColor=%23000000&countColor=%23FFFFFF)
